### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArturSharipov11/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-50/actions)

<a href="https://codeclimate.com/github/ArturSharipov11/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/58ed064c7d939f860240/maintainability" /></a>


![hexlet-check](https://github.com/ArturSharipov11/python-project-50/actions/workflows/hexlet-check/badge.svg)