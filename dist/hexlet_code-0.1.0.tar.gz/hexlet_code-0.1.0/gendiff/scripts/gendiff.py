#!/usr/bin/env python3
from gendiff.main import gen_diff


def main():
    gen_diff()


if __name__ == '__main__':
    main()