def print_diff(args):
    print(args)